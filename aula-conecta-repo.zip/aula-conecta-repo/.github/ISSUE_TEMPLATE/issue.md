---
name: Mejora o bug
about: Sugiere una mejora o reporta un bug
title: "[MÓDULO] Descripción breve"
labels: ["triage"]
assignees: []
---

**Resumen**
Describe el problema o propuesta.

**Pasos para reproducir (si aplica)**
1. 
2. 
3. 

**Criterios de aceptación**
- [ ] 
