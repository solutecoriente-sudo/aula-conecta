## Descripción
Resumen del cambio.

## Checklist
- [ ] Tests o verificación manual
- [ ] Documentación actualizada
