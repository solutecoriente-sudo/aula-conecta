# Política de Seguridad
Reporta vulnerabilidades a security@example.org. No abras issues públicos con PoCs sensibles.
