# Wireframes (bocetos)
Incluye capturas o exporta imágenes aquí. Se adjunta un ejemplo simple en `docs/wireframes`.
