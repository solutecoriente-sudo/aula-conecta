# Arquitectura (propuesta mínima)
- **Frontend estático** (HTML/JS) que consume `src/data/resources.json`.
- **Datos**: metadatos en JSON; fácil de migrar a backend real (FastAPI, Node, etc.).
- **Evolución**: añadir autenticación/roles, carga con versión, rúbricas y calificación.
