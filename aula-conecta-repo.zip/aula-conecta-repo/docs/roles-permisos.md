# Roles y Permisos
- Admin: estructura, cuentas, políticas, reportes
- Docente: recursos, tareas, rúbricas, calificación
- Alumno: acceso a recursos, entrega, ver notas
- Invitado: acceso a recursos públicos
