# Contribuir a Aula Conecta
1. Crea un issue describiendo el cambio.
2. Haz fork, crea rama `feat/tu-feature`.
3. Haz commits atómicos con mensajes claros.
4. Crea un Pull Request con descripción, evidencia y pruebas.
